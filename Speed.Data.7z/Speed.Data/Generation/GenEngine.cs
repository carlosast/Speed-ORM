﻿namespace Speed.Data.Generation
{

    public class GenEngine
    {
    }

}
