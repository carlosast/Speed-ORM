﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Speed.Data
{

    public enum EnumFileChanged
    {
        Unmodified = 0,
        Modified = 1,
        New = 2
    }

}
