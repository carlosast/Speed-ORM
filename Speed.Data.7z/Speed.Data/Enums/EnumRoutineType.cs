﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Speed.Data
{

    public enum EnumRoutineType
    {
        Undefined,
        Procedure,
        Function
    }

}
