﻿namespace Speed.Data
{

    /*
    // // [DataContract]
   // [Serializable]
    public class RecordCollection : Dictionary<string, List<object>>
    {

        // // [DataMember]
        private List<string> keys;

        public RecordCollection()
        {
        }

        // // [DataMember]
        public object this[string columnName]
        {
            get
            {
                return base[columnName];
            }
        }

        public object this[int index]
        {
            get
            {
                return base[index];
            }
        }

    }
    */

}
