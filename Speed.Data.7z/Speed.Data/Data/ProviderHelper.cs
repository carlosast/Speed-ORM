﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Speed.Data.Data
{

    /// <summary>
    /// Common provider methods
    /// </summary>
    public class ProviderHelper
    {
    }
}
