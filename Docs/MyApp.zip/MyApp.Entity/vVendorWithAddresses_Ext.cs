using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Speed;
using Speed.Data;

namespace MyApp.Entity
{

    public partial class vVendorWithAddresses
    {

    }

}
