﻿using System;

namespace MyApp.Entity
{
    public class Class1
    {
    }
}
