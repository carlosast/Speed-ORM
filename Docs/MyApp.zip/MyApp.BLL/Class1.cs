﻿using System;

namespace MyApp.BLL
{
    public class Class1
    {
    }
}
