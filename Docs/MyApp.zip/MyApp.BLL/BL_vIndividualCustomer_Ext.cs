using System;
using System.Collections.Generic;
using System.Data;
using Speed.Data;
using MyApp.Entity;

namespace MyApp.BLL
{

    public partial class BL_vIndividualCustomer
    {

    }

}
