using System;

namespace SourceGrid.Cells.Models
{
	/// <summary>
	/// A generic model interface
	/// </summary>
	public interface IModel
	{
	}
}

