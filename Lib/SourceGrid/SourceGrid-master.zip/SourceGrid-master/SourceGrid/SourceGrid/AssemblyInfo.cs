using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SourceGrid")]
[assembly: AssemblyDescription("Open Source C# Grid Control")]
