using System;
using System.Collections.Generic;

namespace SourceGrid
{
	/// <summary>
	/// A collection of elements of type Position
	/// </summary>
	public class PositionCollection : List<Position>
	{
	}
}
