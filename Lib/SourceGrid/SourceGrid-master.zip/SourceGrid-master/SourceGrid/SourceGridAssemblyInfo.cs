/*
SourceGrid LICENSE (MIT style)
Copyright (c) 2005 - 2012 http://sourcegrid.codeplex.com/
See License.txt.
*/

using System;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("Davide Icardi, Darius Damalakas, http://sourcegrid.codeplex.com, http://bitbucket.org/dariusdamalakas/sourcegrid")]
[assembly: AssemblyCopyright("Davide Icardi, Darius Damalakas")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

//Changed when no more compatible with the previous version
[assembly: AssemblyVersion("4.40.*")]

[assembly: CLSCompliant(true)]

[assembly: System.Runtime.InteropServices.ComVisible(false)]